//
// Created by Alexandru Codreanu on 4/17/17.
//

#ifndef LAB6_DSEXCEPTIONS_H
#define LAB6_DSEXCEPTIONS_H

class UnderflowException { };
class IllegalArgumentException { };
class ArrayIndexOutOfBoundsException { };
class IteratorOutOfBoundsException { };
class IteratorMismatchException { };
class IteratorUninitializedException { };

#endif //LAB6_DSEXCEPTIONS_H
